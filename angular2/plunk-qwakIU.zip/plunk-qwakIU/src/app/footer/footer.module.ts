import { NgModule } from '@angular/core';
import { FooterComponent } from './index';

@NgModule({
    declarations: [
        FooterComponent
    ],
    exports: [
        FooterComponent
    ]
})
export class FooterModule {
}
