export * from './footer.component';
export * from './footer.module';
