import { Routes } from '@angular/router';

import { BriefcaseComponent } from './briefcase.component';

export const BriefcaseRoutes: Routes = [
  { path: 'briefcase',  component: BriefcaseComponent }
];
