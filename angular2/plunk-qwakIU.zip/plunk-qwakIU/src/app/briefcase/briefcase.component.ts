import { Component } from '@angular/core';

@Component({
    selector: 'as-briefcase',
    templateUrl: 'src/app/briefcase/briefcase.html',
    styleUrls: [
        'src/app/briefcase/briefcase.css'
    ]
})
export class BriefcaseComponent {
}
