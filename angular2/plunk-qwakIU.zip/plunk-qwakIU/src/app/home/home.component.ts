import { Component } from '@angular/core';

@Component({
    selector: 'as-home',
    templateUrl: 'src/app/home/home.html',
    styleUrls: [
        'src/app/home/home.css'
    ]
})
export class HomeComponent {
}
